import { NextResponse } from "next/server";
import { getBtcData } from "@/lib/btc";

// The client polls this route every 60s; each call re-fetches upstream
// fresh (no-store), so there's no server cache layer to go stale.
export const dynamic = "force-dynamic";

export async function GET() {
  const data = await getBtcData();
  return NextResponse.json(data);
}
