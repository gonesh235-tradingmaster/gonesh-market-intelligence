import { NextResponse } from "next/server";
import { getNiftyData } from "@/lib/nifty";
import { getBtcData } from "@/lib/btc";

// The client polls this route every 60s; each call re-fetches upstream
// fresh (no-store), so there's no server cache layer to go stale.
export const dynamic = "force-dynamic";

/**
 * Global mood is deliberately NOT a separate score someone made up — it's a
 * weighted blend of the two mood scores that are already computed (and
 * already visible with their own evidence) on the NIFTY and BTC pages.
 */
export async function GET() {
  const [nifty, btc] = await Promise.all([getNiftyData(), getBtcData()]);

  const components = [
    { score: nifty.mood.score, weight: 50 },
    { score: btc.mood.score, weight: 50 },
  ];
  const totalWeight = components.reduce((s, c) => s + c.weight, 0);
  const weightedSum = components.reduce((s, c) => s + c.score * c.weight, 0);
  const score = Math.round(weightedSum / totalWeight);

  return NextResponse.json({
    score,
    niftyMoodScore: nifty.mood.score,
    btcMoodScore: btc.mood.score,
    nifty: nifty.snapshot,
    btc: btc.snapshot,
    fetchedAt: new Date().toISOString(),
  });
}
