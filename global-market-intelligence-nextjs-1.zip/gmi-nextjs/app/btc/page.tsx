"use client";

import React, { useEffect, useState, useCallback } from "react";
import { Header } from "@/components/nav";
import { C, fontSans, fontMono, Card, SectionTitle, MoodBlock, FreshnessBadge, KeyLevel, FactorRow } from "@/components/ui";
import { MoodFactor } from "@/lib/types";

interface BtcData {
  snapshot: any;
  factors: MoodFactor[];
  mood: { score: number; usedWeight: number; totalWeight: number };
  fetchedAt: string;
}

export default function BtcPage() {
  const [data, setData] = useState<BtcData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);

  const load = useCallback(async () => {
    setChecking(true);
    try {
      const res = await fetch("/api/btc", { cache: "no-store" });
      if (!res.ok) throw new Error(`API responded ${res.status}`);
      setData(await res.json());
      setError(null);
    } catch (e: any) {
      setError(e?.message ?? "Failed to load");
    } finally {
      setChecking(false);
    }
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, 60_000);
    return () => clearInterval(id);
  }, [load]);

  const s = data?.snapshot;
  const hasSnapshot = s && !s.note;

  return (
    <>
      <Header onRefresh={load} checking={checking} label="Live — refreshes every 60s" />
      <div style={{ padding: 14, fontFamily: fontSans, color: C.text }}>
        {error && !data && <Card><div style={{ color: C.red, fontSize: 12 }}>Couldn't load: {error}</div></Card>}
        {!data && !error && <Card><div style={{ color: C.textMuted, fontSize: 12 }}>Loading live data…</div></Card>}

        {data && (
          <>
            <SectionTitle sub="24/7 market">Bitcoin (BTC)</SectionTitle>
            <Card>
              {hasSnapshot ? (
                <>
                  <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
                    <span style={{ fontFamily: fontMono, fontSize: 26, color: C.text }}>${s.value.toLocaleString("en-US")}</span>
                    <span style={{ fontFamily: fontMono, fontSize: 14, color: s.changePct >= 0 ? C.green : C.red }}>
                      {s.changePct > 0 ? "+" : ""}{s.changePct}%
                    </span>
                  </div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 }}>
                    {s.dayHigh != null && <KeyLevel label="24h High" value={`$${s.dayHigh.toLocaleString("en-US")}`} />}
                    {s.dayLow != null && <KeyLevel label="24h Low" value={`$${s.dayLow.toLocaleString("en-US")}`} />}
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10, alignItems: "center" }}>
                    <span style={{ fontFamily: fontSans, fontSize: 10.5, color: C.textFaint }}>
                      {s.source} · {s.timestamp ? new Date(s.timestamp).toLocaleString() : "—"}
                    </span>
                    <FreshnessBadge freshness={s.freshness} />
                  </div>
                </>
              ) : (
                <div style={{ color: C.textMuted, fontSize: 12 }}>{s?.note ?? "No data"}</div>
              )}
            </Card>

            <SectionTitle sub="Weighted across verified, non-stale factors only.">BTC Market Mood</SectionTitle>
            <MoodBlock
              title="BTC Mood Score"
              score={data.mood.score}
              explain={`${data.mood.usedWeight}% of ${data.mood.totalWeight}% total weight counted. Factors needing a paid feed (ETF flows, liquidations, rate-hike odds) show as DATA UNAVAILABLE rather than a guess — see the README to wire them up.`}
            />
            {data.factors.map((f) => <FactorRow key={f.id} f={f} />)}
          </>
        )}
      </div>
    </>
  );
}
